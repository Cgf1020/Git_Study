#include "demo.h"

namespace CGF{

void getInfo(std::string &age, std::string &name)
{
    age = "26";
    name = "常高峰 ";
}
}