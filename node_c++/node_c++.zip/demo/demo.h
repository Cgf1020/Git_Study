#ifndef _DEMO_H_
#define _DEMO_H_

#include<iostream>
#include <string>

namespace CGF{
    void getInfo(std::string &age, std::string &name);
}



#endif 